// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"

//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------

//void
//ExceptionHandler(ExceptionType which)
//{
//    int type = machine->ReadRegister(2);
//
//    if ((which == SyscallException) && (type == SC_Halt)) {
//	DEBUG('a', "Shutdown, initiated by user program.\n");
//   	interrupt->Halt();
//    } else {
//	printf("Unexpected user mode exception %d %d\n", which, type);
//	ASSERT(FALSE);
//    }
//}

void AdvancePC()
{
	machine->registers[PrevPCReg] = machine->registers[PCReg];
	machine->registers[PCReg] = machine->registers[NextPCReg];
	machine->registers[NextPCReg] += 4;
	return;
}

char* User2System(int virtAddr, int limit)
{
	int i; 
	int oneChar;
	char* kernelBuf = NULL;
	kernelBuf = new char[limit + 1];
	if (kernelBuf == NULL)
		return kernelBuf;
		
	memset(kernelBuf, 0, limit + 1);
	
	for (i = 0; i < limit; i++)
	{
		machine->ReadMem(virtAddr + i, 1, &oneChar);
		kernelBuf[i] = (char)oneChar;
		if (oneChar == 0)
			break;
	}
	return kernelBuf;
}

int System2User(int virtAddr, int len, char* buffer)
{
	if (len < 0) return -1;
	if (len == 0)return len;
	int i = 0;
	int oneChar = 0;
	do{
		oneChar = (int)buffer[i];
		machine->WriteMem(virtAddr + i, 1, oneChar);
		i++;
	} while (i < len && oneChar != 0);
	return i;
}

void
ExceptionHandler(ExceptionType which)
{
	int type = machine->ReadRegister(2);

	switch(which)
	{
	case SyscallException:
		switch(type)
		{
		case SC_Halt:
		{
			DEBUG('a',"Shutdown,initiated by user program.\n");
			printf("\nShutdown, initiated by user program.");
			interrupt->Halt();
			break;
		}
		case SC_Exit: {
			// đọc exitstatus của tiến trình để join từ thanh ghi r4
			int exitStatus = machine->ReadRegister(4);
			// trả về kết quả và lưu vào exitcode
			int ec = ptable->ExitUpdate(exitStatus);
			// ghi giá trị exitcode vào thanh ghi r2
			machine->WriteRegister(2,ec);
			break;
		}
		case SC_Exec: {
			// đọc địa chỉ từ thanh ghi r4
			int address = machine->ReadRegister(4);
			// chuyển địa chị vừa đọc được từ vùng nhớ userspace sang vùng nhớ systemspace
			char *namefile = User2System(address,255);
			// thực hiện mở file: 
			// nếu xảy ra lỗi thì in ra thông báo lỗi không mở được file và gán -1 vào 				thanh ghi r2
			if (fileSystem->Open(namefile) == NULL){
				gSynchConsole->Write("\nKhong mo duoc file",19);
				machine->WriteRegister(2,-1);
				break;
			}
			// chạy chương trình bằng hàm ExecUpdate trong class ptable
			int id = ptable->ExecUpdate(namefile);
			// ghi id tiến trình vừa exec vào thanh ghi r2
			if (id == -1) {
				machine->WriteRegister(2,-1);
			}
			else {
				machine->WriteRegister(2,id);
			}
			AdvancePC();
			break;
		}
		case SC_Join: {
			// đọc id của tiến trình cần tham gia vào từ thanh ghi r4
			int id = machine->ReadRegister(4);
			// gọi lệnh thực hiện tiến trình và trả về exitcode
			int exitcode = ptable->JoinUpdate(id);
			// trả về exitcode vào thanh ghi r2
			machine->WriteRegister(2, exitcode);
			AdvancePC();
			break;
		}
		case SC_ReadInt:
		{
			DEBUG('a',"Read integer number from console.\n");
			int MAX_INT_LENGTH = 255;
			int number = 0;

			int i ;
			char* buffer = new char[MAX_INT_LENGTH+1];
			int nDigit = gSynchConsole->Read(buffer, MAX_INT_LENGTH);
			int startIndex = buffer[0] == '-' ? 1 : 0;
		
			for (i = startIndex; i < nDigit; i++)
			{
				if (buffer[i] == '.' || buffer[i]<'0' || buffer[i]>'9')
				{
					printf("\nThe number is not valid! ");
					DEBUG('a',"\nThe integer number is not valid");
					machine->WriteRegister(2,0);
					AdvancePC();
					delete buffer;
					return;
				}
			}


			for (i = startIndex; i < nDigit; i++)
			{
				number = number*10 + (int) (buffer[i] - 48);
			}
			number = buffer[0] == '-' ? -1*number : number;
			machine->WriteRegister(2,number);
			AdvancePC();
			delete buffer;
			return;
		}
		case SC_PrintInt:
		{
			int number = machine->ReadRegister(4);
			if (number == 0)
			{
				gSynchConsole->Write("0",1);
				AdvancePC();
				return;
			}
			number = number < 0 ? -1*number : number;
			int start_index = number < 0  ? 1 : 0;

			int temp = number;
			int nDigit = 0;
			int MAX_INT_LENGTH = 255;
			while(temp!=0)
			{
				nDigit++;
				temp /= 10;
			}
			char* buffer = new char[MAX_INT_LENGTH];

			for (int i = start_index + nDigit -1; i >= start_index; i--)
			{
				buffer[i] = (char) ((number % 10) +48);
				number /= 10;
			}

			if (number < 0)
			{
				buffer[0] = '-';
				buffer[nDigit + 1] = '\0';
				gSynchConsole->Write(buffer, nDigit+1);
			}
			else
			{
				buffer[nDigit] = '\0';
				gSynchConsole->Write(buffer, nDigit);
			}
			delete buffer;
			AdvancePC();
			return;
		}
		case SC_ReadChar:
		{
			/*************************************************************************************
			--->Xử lý hàm ReadChar (char ReadChar())<---
			- Công dụng	: đọc một ký tự do người dùng nhập vào từ bàn phím
			- Input    	: không có tham số đầu vào
			- Output	: không có output, chỉ thực hiện đọc "một" ký tự do người dùng nhập vào
			- Quá trình	: ta khai báo con trỏ "buffer" là chuỗi chứa tối đa "maxBytes" kí tự mà 						  người dùng nhập vào, sử dụng phương thức Read() trong file 							  "synchcons.h" để đọc những gì mà người dùng nhập từ bàn phím và dùng 						  numByteUsed để lưu số bytes (số ký tự) mà người dùng vừa nhập từ bàn 						  phím
			- Kết quả	:  
				+ nếu số lượng kí tự người dùng nhập vượt quá một -> không khỏa yêu cầu nhập 						  "một kí tự" -> xuất lỗi: chỉ được nhập một ký tự và lưu giá trị 0 và thành ghi 					  2 thể hiện cho việc người dùng nhập lỗi
				+ nếu số lượng kí tự người dùng nhập bằng 0 hay người dùng không nhập gì cả -> 					  xuất lỗi: ký tự rỗng và lưu giá trị 0 và thành ghi 2 thể hiện cho việc người 					  dùng nhập lỗi
				+ nếu người dùng nhập đúng một ký tự, tức lúc này chuỗi buffer chỉ chứa một ký 					  tự, trả về ký tự c = buffer[0] vào thanh ghi $2
			**************************************************************************************/
			int maxBytes = 256;
			char* buffer = new char[maxBytes];
			int numBytesUsed = gSynchConsole->Read(buffer, maxBytes);

			if(numBytesUsed > 1){
			 	//Nếu nhập nhiều hơn một ký tự thì không hợp lệ				
				printf("Chi duoc nhap duy nhat 1 ky tu!");
				DEBUG('a', "\nERROR: Chi duoc nhap duy nhat 1 ky tu!");

				//Lưu giá trị 0 thành thanh ghi $2
				machine->WriteRegister(2, 0);
			}else if(numBytesUsed == 0){
				//Nếu không nhập gì thì cũng không hợp lệ
				printf("Ky tu rong!");
				DEBUG('a', "\nERROR: Ky tu rong!");
				
				//Lưu giá trị 0 thành thanh ghi $2
				machine->WriteRegister(2, 0);
			}else{
				//Chuỗi buffer vừa được người dùng nhập từ bàn phím có đúng một kí tự 
				char c = buffer[0];
			
				//Trả về kí tự c vào thanh ghi 2 nếu nhập đúng
				machine->WriteRegister(2, c);
			}
			
			delete buffer;
			AdvancePC();
			break;
		}
		case SC_PrintChar:
		{
			/*************************************************************************************
			--->Xử lý hàm PrintChar (void PrintChar(char character))<---
			- Công dụng	: xuất một ký tự ra màn hình
			- Input    	: ký tự "character" cần xuất ra màn hình
			- Output	: ký tự đọc được từ thanh ghi số 4 (vì chỉ có một tham số đầu vào là 							  character nên nó được lưu ở thanh ghi $4)
			- Quá trình	: sau khi đọc giá trị của tham số truyền vào tại thanh ghi $4 (trả về 						   int), ta ép kiểu về char rồi xuất ký tự này ra màn hình bằng hàm 						  Write trong file "synchcons.h" với số lượng bytes là 1
			- Kết quả 	: ký tự (tham số đầu vào character) được ghi ra màn hình console
			**************************************************************************************/	
			//Đọc giá trị của tham số truyền vào tại thanh ghi $4 rồi ép kiểu về char		
			char c = (char)machine->ReadRegister(4);

			//In ký tự c vừa đọc được ra màn hình
			gSynchConsole->Write(&c, 1); 
			AdvancePC();
			break;

		}
		case SC_ReadString:
		{
			/*************************************************************************************
			--->Xử lý hàm ReadString (void ReadString (char[] buffer, int length))<---
			- Công dụng	: đọc một chuỗi tối đa "length" ký tự vào trong buffer 
			- Input    	: chuỗi "buffer", độ dài tối đa "length"
			- Output	: đọc chuỗi ký tự tại địa chỉ lấy từ thanh ghi $4 với độ dài tối đa lấy 						  từ thanh ghi $5
			- Quá trình	: sau khi đọc địa chỉ của buffer từ thanh ghi $4 (lưu vào con trỏ 						   buffAddr) và độ dài tối đa từ thanh ghi $5(lưu vào length), ta chuyển 					  chuỗi trong con  trỏ bufAddr(UserSpace) sang địa chỉ 						   buffer(SystemSpace) để đọc chuỗi mà người dùng sắp nhập từ bàn phím 						  với hàm Read trong file "synchcons.h", sau khi đọc xong, ta chuyển 						  ngược chuỗi trong vùng nhớ buffer (SystemSpace) trở lại vùng nhớ 						   buffAddr (UserSpace)
			- Kết quả 	: chuỗi kí tự do người dùng nhập được đọc vào buffer (thuộc vùng user space)
			**************************************************************************************/
			int buffAddr, length;
			char* buffer;

			//Đọc địa chỉ chuỗi buffer từ thanh ghi $4 (con trỏ giữ vùng nhớ buffer)
			buffAddr = machine->ReadRegister(4); 

			//Đọc giá trị length từ thanh ghi $5
			length = machine->ReadRegister(5); 
			
			//Chuyển chuỗi trong con trỏ buffAddr sang vùng nhớ buffer
			buffer = User2System(buffAddr, length); 
			
			//Sử dụng hàm Read trong file "synchcons.h" để đọc chuỗi từ console (nhập từ bàn phím)
			gSynchConsole->Read(buffer, length); 
			
			//Ghi chuỗi buffer được cấp phát với độ dài length (ở vùng kernelspace) vào vùng nhớ 				mà buffAddr đang giữ (vùng nhớ thuộc userspace)
			System2User(buffAddr, length, buffer); 

			delete buffer; 
			AdvancePC();
			break;
		}
		case SC_PrintString:
		{
			/*************************************************************************************
			--->Xử lý hàm PrintString (void PrintString (char[] buffer))<---
			- Công dụng	: in chuỗi ký tự trong buffer ra màn hình console
			- Input    	: chuỗi "buffer"
			- Output	: đọc chuỗi ký tự tại địa chỉ lấy từ thanh ghi $4 với số lượng kí tự là độ dài 						  thật của chuỗi kí tự tại vùng nhớ vừa đọc được
			- Quá trình	: sau khi đọc địa chỉ của buffer từ thanh ghi $4 (lưu vào con trỏ 						   buffAddr), ta chuyển chuỗi trong con  trỏ bufAddr(UserSpace) sang địa chỉ 						   buffer(SystemSpace) để dựa vào chuỗi kí tự này đếm độ dài thật rồi sử dụng 						  hàm Write trong file "synchcons.h" để đọc chuỗi kí tự với độ dài thật (+1) ra 					  màn hình console
			- Kết quả 	: chuỗi kí tự tại vùng nhớ buffer được in ra màn hình console
			**************************************************************************************/
			int buffAddr;
			char* buffer;
			
			//Đọc địa chỉ chuỗi buffer từ thanh ghi $4 (con trỏ giữ vùng nhớ buffer)
			buffAddr = machine->ReadRegister(4); 
			
			//Chuyển chuỗi trong con trỏ buffAddr (thuộc vùng nhớ userspace) sang vùng nhớ buffer (thuộc 				vùng nhớ kernelspace) với độ dài tối đa 256 kí tự 
			buffer = User2System(buffAddr, 256); 
			
			//Đếm độ dài thật của chuỗi kí tự
			int length = 0;
			while (buffer[length] != 0) length++;
			
			//Sau khi đếm độ dài thật của chuỗi kí tự vừa nhập từ bàn phím (+1), ta sử dụng hàm Write trong 				file "synchcons.h" để in ra màn hình console chuỗi kí tự trong vùng nhớ buffer (thuộc vùng nhớ 				kernel space)
			gSynchConsole->Write(buffer, length + 1); 

			delete buffer; 
			AdvancePC();
			break;
		}
		}
		break;
	case NoException:
		return;
	case PageFaultException:
		DEBUG('a', "\nPageFault Error - No valid translation found !");
		printf("PageFault Error - No valid translation found !");
		ASSERT(FALSE);
		interrupt->Halt();
		break;
	case ReadOnlyException:
		DEBUG('a', "\nReadOnly Error - Write attempted to page marked read-only !");
		printf("ReadOnly Error - Write attempted to page marked read-only !");
		ASSERT(FALSE);
		interrupt->Halt();
		break;
	case BusErrorException:
		DEBUG('a', "\nBus Error - Translation resulted in an invalid physical address !");
		printf("Bus Error - Translation resulted in an invalid physical address !");
		ASSERT(FALSE);
		interrupt->Halt();	
		break;
	case AddressErrorException:
		DEBUG('a', "\nAddress Error - Unaligned reference or one that was beyond the end of the address space");
		printf("Address Error - Unaligned reference or one that was beyond the end of the address space");
		ASSERT(FALSE);
		interrupt->Halt();
		break;
	case OverflowException:
		DEBUG('a', "\nOverflow Error - Integer overflow in add or sub !");
		printf("Overflow Error - Integer overflow in add or sub !");
		ASSERT(FALSE);
		interrupt->Halt();
		break;
	case IllegalInstrException:
		DEBUG('a', "\nIllegal In Str Error - Unimplemented or reserved instr !");
		printf("Illegal In Str Error - Unimplemented or reserved instr !");
		ASSERT(FALSE);
		interrupt->Halt();
		break;
	case NumExceptionTypes:
		DEBUG('a', "\nNum Types Error ! ");
		printf("Num Types Error ! ");
		ASSERT(FALSE);
		interrupt->Halt();
		break;
	default:
		printf("Unexpected user mode exception %d %d\n",which,type);
		ASSERT(FALSE);
		break;
	}
}













