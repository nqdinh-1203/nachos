#include "syscall.h"
#include "copyright.h"

int main()
{
	int number;
	number =ReadInt();
	PrintInt(number);
	Halt();
	return 0;
}
