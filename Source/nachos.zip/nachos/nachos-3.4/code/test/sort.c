#include "syscall.h"

int
main()
{
	int A[100];
	int i, j, tmp;
	int size = 0;
	
	// Nhap so luong phan tu trong mang
	do{
		PrintString("Input size (0 < size <= 100) = ");
		size = ReadInt();
	}while(size <= 0 && size > 100);


	// Nhap tung phan tu trong mang A
	for(i = 0; i < size; i++){
		PrintString("Input A[");
		PrintInt(i);
		PrintString("] = ");
		A[i] = ReadInt();
	}

	// Bubble Sort
	for(i = 0; i < size - 1; i++){
		for(j = 0; j < size - i - 1; j++)
			if(A[j] > A[j + 1]){
				tmp = A[j];
				A[j] = A[j + 1];
				A[j + 1] = tmp;
			}	
	}

	// Xuat ra mang da Sort
	for(i = 0; i < size; i++){
		PrintInt(A[i]);
		PrintChar('\t');	
	}
	return 0;
}

