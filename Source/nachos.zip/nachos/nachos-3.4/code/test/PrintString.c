#include "syscall.h"

int main() {
	PrintString("Day la chuoi ky tu\n");	
	return 0;
}
