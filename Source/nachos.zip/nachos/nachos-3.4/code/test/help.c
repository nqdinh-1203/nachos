#include "syscall.h"

int main() {
	PrintString("Nguyen Quang Dinh - 19120478\n");
	PrintString("Huynh Quoc Duy - 19120494\n");
	PrintString("Pham Duc Huy - 19120534\n");
	PrintString("Le Thanh Loc - 19120562\n");
	PrintString("Chuong trinh ascii: xuat ra bang ma ASCII\n");
	PrintString("Chuong trinh sap xep bang thuat toan BubbleSort\n");
	PrintString("\t+ Buoc 1: Nhap mang\n\t+ Buoc 2: Sap xep\n\t+ Buoc 3: Xuat mang\n");

	return 0;
}
